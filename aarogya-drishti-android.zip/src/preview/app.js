const cases = [
  { initials: 'RM', name: 'Ravi Mallesh', id: 'AD-240918', village: 'Kondapalli', finding: 'White patch · Buccal mucosa', risk: 86, status: 'Needs review', tone: 'high', time: '12 min ago', avatar: 'a0' },
  { initials: 'SL', name: 'Sita Lakshmi', id: 'AD-240917', village: 'Maredumilli', finding: 'Persistent ulcer · Tongue', risk: 64, status: 'Referred', tone: 'medium', time: '38 min ago', avatar: 'a1' },
  { initials: 'VK', name: 'Venkat Kumar', id: 'AD-240916', village: 'Rampachodavaram', finding: 'No concerning findings', risk: 12, status: 'Completed', tone: 'low', time: '1 hr ago', avatar: 'a2' },
  { initials: 'PD', name: 'Padma Devi', id: 'AD-240915', village: 'Gangavaram', finding: 'Red patch · Lower lip', risk: 72, status: 'Needs review', tone: 'high', time: '2 hrs ago', avatar: 'a3' },
];
const $ = (id) => document.getElementById(id);
let toastTimer;
function toast(message) {
  const el = $('toast'); el.textContent = `✓  ${message}`; el.classList.remove('hidden');
  clearTimeout(toastTimer); toastTimer = setTimeout(() => el.classList.add('hidden'), 2600);
}
function renderCases() {
  const q = $('search').value.trim().toLowerCase();
  const filtered = cases.filter(c => `${c.name} ${c.id} ${c.village}`.toLowerCase().includes(q));
  $('shown').textContent = filtered.length;
  $('case-rows').innerHTML = filtered.map(c => `<tr tabindex="0" data-case="${c.id}"><td><div class="patient"><span class="patient-avatar ${c.avatar}">${c.initials}</span><span><b>${c.name}</b><small>${c.id} <i>·</i> ${c.village}</small></span></div></td><td>${c.finding}</td><td><span class="risk ${c.tone}"><i></i>${c.risk}% risk</span></td><td><span class="status ${c.tone}">${c.tone !== 'low' ? '<i></i>' : ''}${c.status}</span></td><td class="time">${c.time}</td><td><button class="row-arrow" aria-label="View ${c.name}" data-case="${c.id}">→</button></td></tr>`).join('');
  $('empty').classList.toggle('hidden', filtered.length !== 0);
}
function openCase(id) {
  const c = cases.find(item => item.id === id); if (!c) return;
  $('drawer-content').innerHTML = `<div class="drawer-patient"><span class="patient-avatar ${c.avatar}">${c.initials}</span><h2>${c.name}</h2><p>${c.id} · ${c.village}</p><span class="risk ${c.tone}"><i></i>${c.risk}% risk</span></div><section class="drawer-section"><small>SCREENING FINDING</small><h3>${c.finding}</h3><p>AI-assisted screening result. A qualified clinician should review the image and clinical context before diagnosis.</p></section><section class="drawer-section journey"><small>CARE JOURNEY</small><div class="step done"><i></i><span><b>Screening completed</b><small>Today · 9:42 AM</small></span></div><div class="step current"><i></i><span><b>Doctor review</b><small>Awaiting clinician assessment</small></span></div><div class="step"><i></i><span><b>Referral &amp; follow-up</b><small>Next step</small></span></div></section><button class="primary drawer-button" id="open-full">▤ Open full case</button><button class="secondary drawer-message" id="contact-team">☏ Contact care team</button>`;
  $('drawer').classList.remove('hidden');
  $('open-full').addEventListener('click', () => { $('drawer').classList.add('hidden'); toast('Case opened for clinical review'); });
  $('contact-team').addEventListener('click', () => toast('Message sent to care team'));
}
renderCases();
$('search').addEventListener('input', renderCases);
$('case-rows').addEventListener('click', e => { const target = e.target.closest('[data-case]'); if (target) openCase(target.dataset.case); });
$('case-rows').addEventListener('keydown', e => { if (e.key === 'Enter' && e.target.dataset.case) openCase(e.target.dataset.case); });
$('register').addEventListener('click', () => $('modal').classList.remove('hidden'));
function closeModal() { $('modal').classList.add('hidden'); }
$('modal-close').addEventListener('click', closeModal); $('cancel').addEventListener('click', closeModal);
$('modal').addEventListener('click', e => { if (e.target === $('modal')) closeModal(); });
$('patient-form').addEventListener('submit', e => { e.preventDefault(); closeModal(); e.target.reset(); toast('Patient registered · Offline ready'); });
$('online').addEventListener('click', () => { const button = $('online'); const online = button.classList.toggle('offline'); button.querySelector('span').textContent = online ? 'Offline' : 'Online'; toast(online ? 'Offline mode enabled' : 'Back online · Syncing records'); });
$('bell').addEventListener('click', e => { e.stopPropagation(); $('popover').classList.toggle('hidden'); });
document.addEventListener('click', e => { if (!e.target.closest('.notification-wrap')) $('popover').classList.add('hidden'); });
$('help').addEventListener('click', () => toast('Help centre · Call 1800-XXX-XXXX'));
$('campaign').addEventListener('click', () => toast('Community screening · Friday in Maredumilli'));
$('dismiss').addEventListener('click', () => document.querySelector('.notice').remove());
$('period').addEventListener('click', () => { const span = $('period').querySelector('span'); span.textContent = span.textContent === '7 days' ? '30 days' : '7 days'; });
$('export').addEventListener('click', () => toast('Screening report downloaded'));
$('filter').addEventListener('click', () => toast('Showing high priority and recent cases'));
$('assistant').addEventListener('click', () => toast('Voice assistant · English / తెలుగు'));
document.querySelectorAll('[data-action]').forEach(button => button.addEventListener('click', () => toast(`Opening ${button.dataset.action}`)));
$('drawer-close').addEventListener('click', () => $('drawer').classList.add('hidden'));
$('drawer').addEventListener('click', e => { if (e.target === $('drawer')) $('drawer').classList.add('hidden'); });
function closeNav() { $('sidebar').classList.remove('mobile-open'); $('scrim').classList.remove('show'); }
$('menu-button').addEventListener('click', () => { $('sidebar').classList.add('mobile-open'); $('scrim').classList.add('show'); });
$('close-nav').addEventListener('click', closeNav); $('scrim').addEventListener('click', closeNav);
document.querySelectorAll('.nav-link').forEach(link => link.addEventListener('click', () => { document.querySelectorAll('.nav-link').forEach(x => x.classList.remove('active')); link.classList.add('active'); closeNav(); }));
document.addEventListener('keydown', e => { if (e.key === 'Escape') { closeModal(); $('drawer').classList.add('hidden'); $('popover').classList.add('hidden'); closeNav(); } });
