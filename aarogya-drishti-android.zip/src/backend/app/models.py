from datetime import datetime
from enum import Enum

from sqlalchemy import DateTime, Enum as SqlEnum, Float, ForeignKey, Integer, String, Text, func
from sqlalchemy.orm import Mapped, mapped_column, relationship

from .database import Base


class Role(str, Enum):
    HEALTH_WORKER = "health_worker"
    PATIENT = "patient"
    DOCTOR = "doctor"
    SPECIALIST = "specialist"
    DISTRICT_ADMIN = "district_admin"
    SUPER_ADMIN = "super_admin"


class CaseStatus(str, Enum):
    SCREENING = "screening"
    UNDER_REVIEW = "under_review"
    REFERRED = "referred"
    DIAGNOSED = "diagnosed"
    UNDER_TREATMENT = "under_treatment"
    RECOVERED = "recovered"


class User(Base):
    __tablename__ = "users"

    id: Mapped[int] = mapped_column(primary_key=True)
    full_name: Mapped[str] = mapped_column(String(160))
    email: Mapped[str] = mapped_column(String(254), unique=True, index=True)
    password_hash: Mapped[str] = mapped_column(String(255))
    role: Mapped[Role] = mapped_column(SqlEnum(Role), default=Role.HEALTH_WORKER)
    is_active: Mapped[bool] = mapped_column(default=True)
    created_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), server_default=func.now())


class Patient(Base):
    __tablename__ = "patients"

    id: Mapped[int] = mapped_column(primary_key=True)
    patient_code: Mapped[str] = mapped_column(String(32), unique=True, index=True)
    full_name: Mapped[str] = mapped_column(String(160), index=True)
    age: Mapped[int] = mapped_column(Integer)
    gender: Mapped[str | None] = mapped_column(String(32), nullable=True)
    mobile_number: Mapped[str | None] = mapped_column(String(32), nullable=True)
    village: Mapped[str] = mapped_column(String(120), index=True)
    district: Mapped[str] = mapped_column(String(120), index=True)
    occupation: Mapped[str | None] = mapped_column(String(120), nullable=True)
    tobacco_usage: Mapped[str | None] = mapped_column(String(80), nullable=True)
    smoking_history: Mapped[str | None] = mapped_column(String(120), nullable=True)
    alcohol_consumption: Mapped[str | None] = mapped_column(String(80), nullable=True)
    symptoms: Mapped[str | None] = mapped_column(Text, nullable=True)
    existing_diseases: Mapped[str | None] = mapped_column(Text, nullable=True)
    previous_cancer_history: Mapped[bool] = mapped_column(default=False)
    created_by_id: Mapped[int | None] = mapped_column(ForeignKey("users.id"), nullable=True)
    created_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), server_default=func.now())
    screenings: Mapped[list["Screening"]] = relationship(back_populates="patient", cascade="all, delete-orphan")


class Screening(Base):
    __tablename__ = "screenings"

    id: Mapped[int] = mapped_column(primary_key=True)
    patient_id: Mapped[int] = mapped_column(ForeignKey("patients.id", ondelete="CASCADE"), index=True)
    captured_by_id: Mapped[int | None] = mapped_column(ForeignKey("users.id"), nullable=True)
    status: Mapped[CaseStatus] = mapped_column(SqlEnum(CaseStatus), default=CaseStatus.SCREENING)
    created_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), server_default=func.now())
    patient: Mapped[Patient] = relationship(back_populates="screenings")
    images: Mapped[list["ScreeningImage"]] = relationship(back_populates="screening", cascade="all, delete-orphan")
    ai_result: Mapped["AIResult | None"] = relationship(back_populates="screening", cascade="all, delete-orphan", uselist=False)


class ScreeningImage(Base):
    __tablename__ = "screening_images"

    id: Mapped[int] = mapped_column(primary_key=True)
    screening_id: Mapped[int] = mapped_column(ForeignKey("screenings.id", ondelete="CASCADE"), index=True)
    category: Mapped[str] = mapped_column(String(40))
    blob_key: Mapped[str] = mapped_column(String(500))
    content_sha256: Mapped[str | None] = mapped_column(String(64), nullable=True)
    created_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), server_default=func.now())
    screening: Mapped[Screening] = relationship(back_populates="images")


class AIResult(Base):
    __tablename__ = "ai_results"

    id: Mapped[int] = mapped_column(primary_key=True)
    screening_id: Mapped[int] = mapped_column(ForeignKey("screenings.id", ondelete="CASCADE"), unique=True)
    risk_level: Mapped[str] = mapped_column(String(24))
    risk_score: Mapped[float] = mapped_column(Float)
    model_name: Mapped[str] = mapped_column(String(100))
    model_version: Mapped[str] = mapped_column(String(80))
    explainability_blob_key: Mapped[str | None] = mapped_column(String(500), nullable=True)
    clinician_review_required: Mapped[bool] = mapped_column(default=True)
    created_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), server_default=func.now())
    screening: Mapped[Screening] = relationship(back_populates="ai_result")


class Referral(Base):
    __tablename__ = "referrals"

    id: Mapped[int] = mapped_column(primary_key=True)
    screening_id: Mapped[int] = mapped_column(ForeignKey("screenings.id", ondelete="CASCADE"), index=True)
    hospital_name: Mapped[str | None] = mapped_column(String(200), nullable=True)
    appointment_at: Mapped[datetime | None] = mapped_column(DateTime(timezone=True), nullable=True)
    status: Mapped[str] = mapped_column(String(40), default="pending")
    notes: Mapped[str | None] = mapped_column(Text, nullable=True)
    created_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), server_default=func.now())
