from contextlib import asynccontextmanager
from uuid import uuid4

from fastapi import Depends, FastAPI, HTTPException, Query, status
from fastapi.middleware.cors import CORSMiddleware
from fastapi.security import OAuth2PasswordRequestForm
from sqlalchemy import select
from sqlalchemy.orm import Session

from .database import Base, engine, get_db
from .auth import current_user, require_roles
from .models import Patient, Role, User
from .schemas import PatientCreate, PatientRead
from .security import create_access_token, verify_password
from .settings import settings


@asynccontextmanager
async def lifespan(_: FastAPI):
    # For local bootstrap only. Production deployments should use Alembic migrations.
    Base.metadata.create_all(bind=engine)
    yield


app = FastAPI(title=settings.app_name, version="0.1.0", lifespan=lifespan)
app.add_middleware(
    CORSMiddleware,
    allow_origins=[origin.strip() for origin in settings.cors_origins.split(",") if origin.strip()],
    allow_credentials=True,
    allow_methods=["GET", "POST", "OPTIONS"],
    allow_headers=["Authorization", "Content-Type"],
)


@app.get("/health")
def health():
    return {"status": "ok", "service": "aarogya-drishti-api"}


@app.post("/api/v1/auth/token")
def login(form: OAuth2PasswordRequestForm = Depends(), db: Session = Depends(get_db)):
    user = db.scalar(select(User).where(User.email == form.username, User.is_active.is_(True)))
    if user is None or not verify_password(form.password, user.password_hash):
        raise HTTPException(status_code=status.HTTP_401_UNAUTHORIZED, detail="Invalid email or password")
    return {"access_token": create_access_token(user.email, user.role.value), "token_type": "bearer", "expires_in": settings.access_token_minutes * 60}


@app.post("/api/v1/patients", response_model=PatientRead, status_code=status.HTTP_201_CREATED)
def create_patient(payload: PatientCreate, db: Session = Depends(get_db), user: User = Depends(require_roles(Role.HEALTH_WORKER, Role.DOCTOR, Role.SPECIALIST, Role.DISTRICT_ADMIN, Role.SUPER_ADMIN))):
    patient = Patient(patient_code=f"AD-{uuid4().hex[:8].upper()}", created_by_id=user.id, **payload.model_dump())
    db.add(patient)
    db.commit()
    db.refresh(patient)
    return patient


@app.get("/api/v1/patients", response_model=list[PatientRead])
def list_patients(q: str | None = Query(default=None, max_length=120), limit: int = Query(default=50, ge=1, le=100), db: Session = Depends(get_db), _: User = Depends(current_user)):
    statement = select(Patient).order_by(Patient.created_at.desc()).limit(limit)
    if q:
        statement = statement.where(Patient.full_name.ilike(f"%{q}%") | Patient.patient_code.ilike(f"%{q}%"))
    return list(db.scalars(statement))


@app.get("/api/v1/patients/{patient_id}", response_model=PatientRead)
def get_patient(patient_id: int, db: Session = Depends(get_db), _: User = Depends(current_user)):
    patient = db.get(Patient, patient_id)
    if patient is None:
        raise HTTPException(status_code=404, detail="Patient not found")
    return patient
