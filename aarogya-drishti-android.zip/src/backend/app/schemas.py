from datetime import datetime

from pydantic import BaseModel, ConfigDict, Field


class PatientCreate(BaseModel):
    full_name: str = Field(min_length=1, max_length=160)
    age: int = Field(ge=1, le=120)
    gender: str | None = None
    mobile_number: str | None = Field(default=None, max_length=32)
    village: str = Field(min_length=1, max_length=120)
    district: str = Field(min_length=1, max_length=120)
    occupation: str | None = None
    tobacco_usage: str | None = None
    smoking_history: str | None = None
    alcohol_consumption: str | None = None
    symptoms: str | None = None
    existing_diseases: str | None = None
    previous_cancer_history: bool = False


class PatientRead(BaseModel):
    model_config = ConfigDict(from_attributes=True)
    id: int
    patient_code: str
    full_name: str
    age: int
    gender: str | None
    mobile_number: str | None
    village: str
    district: str
    created_at: datetime
