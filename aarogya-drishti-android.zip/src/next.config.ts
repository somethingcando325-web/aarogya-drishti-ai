import type { NextConfig } from 'next';
// Static export so the app can be packaged inside the Android (Capacitor) shell.
const nextConfig: NextConfig = { poweredByHeader: false, output: 'export', images: { unoptimized: true }, trailingSlash: true };
export default nextConfig;
