# Aarogya Drishti AI

A responsive, community-first oral health screening and care coordination platform starter. The Next.js dashboard includes screening activity, village coverage, case triage, patient registration, notifications, offline state, and care journey interactions.

## Run the frontend

Requirements: Node.js 20 or newer.

```bash
npm install
npm run dev
```

Open http://localhost:3000.

If frontend dependencies cannot be downloaded, open a no-install visual preview with `npm run preview` (uses Node.js built-ins) at http://localhost:3100. The preview keeps the dashboard interactions usable but is separate from the Next.js application build. Set `PORT` to choose a different port.

## What's included

- Next.js 15, React 19, TypeScript, Tailwind CSS 4, Framer Motion, Recharts, and Lucide icons.
- Responsive district dashboard, patient registration modal, searchable case list, case details drawer, connectivity toggle, and notification panel.
- FastAPI backend scaffold under `backend/` with JWT roles, SQLAlchemy models, and explicit interfaces for clinical AI and secure image storage.

## API scaffold

```bash
cd backend
python -m venv .venv
# Windows: .venv\Scripts\activate
pip install -r requirements.txt
uvicorn app.main:app --reload
```

The API defaults to SQLite for local development. Set `DATABASE_URL`, `JWT_SECRET`, and `CORS_ORIGINS` for deployment. The API exposes `/health` and `/api/v1/patients`.

## Clinical and deployment notes

The dashboard uses sample aggregate and case data. It is a product starter, not a clinically validated screening tool. No lesion classifier is bundled: connect a validated, versioned model behind the backend's `ScreeningService` interface and require clinician review before diagnosis or treatment. Image upload, Azure Blob integration, live Agora/WebRTC sessions, SMS/WhatsApp, and production offline synchronization require credentials, privacy controls, consent and retention policies, and deployment configuration; the dashboard's offline toggle is a UI demonstration only.

Before handling real patient data, implement appropriate consent, encryption and access controls, audit logging, regional health-data requirements, security review, validated clinical workflow, and backup/recovery policies.
