import type { Metadata } from 'next';
import './globals.css';

export const metadata: Metadata = {
  title: 'Aarogya Drishti AI | Community oral health',
  description: 'A community-first oral health screening and care coordination platform.',
};

export default function RootLayout({ children }: Readonly<{ children: React.ReactNode }>) {
  return <html lang="en"><body>{children}</body></html>;
}
