'use client';

import { useMemo, useState } from 'react';
import { motion } from 'framer-motion';
import { Activity, ArrowDownRight, ArrowRight, ArrowUpRight, AudioLines, Bell, CalendarDays, Check, ChevronDown, ChevronLeft, ChevronRight, CircleHelp, ClipboardCheck, Clock3, Cloud, CloudOff, Download, FileText, Filter, Headphones, HeartPulse, LayoutDashboard, MapPin, Menu, MessageCircle, MoreHorizontal, Plus, Search, Settings2, ShieldCheck, Stethoscope, Users, X } from 'lucide-react';
import { Area, AreaChart, CartesianGrid, ResponsiveContainer, Tooltip, XAxis, YAxis } from 'recharts';

const weekly = [
  { day: 'Mon', count: 28 }, { day: 'Tue', count: 42 }, { day: 'Wed', count: 35 }, { day: 'Thu', count: 58 },
  { day: 'Fri', count: 45 }, { day: 'Sat', count: 67 }, { day: 'Sun', count: 52 },
];

const cases = [
  { initials: 'RM', name: 'Ravi Mallesh', id: 'AD-240918', village: 'Kondapalli', finding: 'White patch · Buccal mucosa', risk: 86, status: 'Needs review', tone: 'high', time: '12 min ago' },
  { initials: 'SL', name: 'Sita Lakshmi', id: 'AD-240917', village: 'Maredumilli', finding: 'Persistent ulcer · Tongue', risk: 64, status: 'Referred', tone: 'medium', time: '38 min ago' },
  { initials: 'VK', name: 'Venkat Kumar', id: 'AD-240916', village: 'Rampachodavaram', finding: 'No concerning findings', risk: 12, status: 'Completed', tone: 'low', time: '1 hr ago' },
  { initials: 'PD', name: 'Padma Devi', id: 'AD-240915', village: 'Gangavaram', finding: 'Red patch · Lower lip', risk: 72, status: 'Needs review', tone: 'high', time: '2 hrs ago' },
];

const villages = [
  { name: 'Rampachodavaram', count: 128, high: 12, width: '82%' }, { name: 'Maredumilli', count: 96, high: 8, width: '63%' },
  { name: 'Y. Ramavaram', count: 74, high: 6, width: '48%' }, { name: 'Devipatnam', count: 51, high: 4, width: '34%' },
];

const navItems = [
  { label: 'Overview', icon: LayoutDashboard }, { label: 'Patients', icon: Users, badge: '12' },
  { label: 'Screenings', icon: Activity }, { label: 'Referrals', icon: ClipboardCheck, badge: '8', active: true },
];

function Logo() {
  return <div className="brand-mark"><div className="brand-icon"><HeartPulse size={20} strokeWidth={2.2} /></div><div><div className="brand-name">aarogya<span>.</span></div><div className="brand-caption">DRISHTI AI</div></div></div>;
}

function RiskPill({ risk, tone }: { risk: number; tone: string }) {
  return <div className={`risk-pill ${tone}`}><span className="risk-dot" />{risk}% risk</div>;
}

export default function Dashboard() {
  const [activeNav, setActiveNav] = useState('Referrals');
  const [activePeriod, setActivePeriod] = useState('7 days');
  const [query, setQuery] = useState('');
  const [showRegistration, setShowRegistration] = useState(false);
  const [showNotifications, setShowNotifications] = useState(false);
  const [isOnline, setIsOnline] = useState(true);
  const [toast, setToast] = useState('');
  const [mobileMenu, setMobileMenu] = useState(false);
  const [selectedCase, setSelectedCase] = useState<string | null>(null);
  const visibleCases = useMemo(() => cases.filter(c => `${c.name} ${c.id} ${c.village}`.toLowerCase().includes(query.toLowerCase())), [query]);

  function announce(message: string) {
    setToast(message);
    window.setTimeout(() => setToast(''), 2600);
  }

  return (
    <main className="app-shell">
      <aside className={`sidebar ${mobileMenu ? 'sidebar-open' : ''}`}>
        <div className="sidebar-top"><Logo /><button className="icon-button mobile-close" aria-label="Close menu" onClick={() => setMobileMenu(false)}><X size={18} /></button></div>
        <button className="workspace-switch"><div className="workspace-avatar">ED</div><div className="workspace-copy"><strong>East Godavari</strong><span>District workspace</span></div><ChevronDown size={15} className="muted" /></button>
        <div className="nav-section-label">WORKSPACE</div>
        <nav className="main-nav">{navItems.map(({ label, icon: Icon, badge }) => <button key={label} className={`nav-item ${activeNav === label ? 'selected' : ''}`} onClick={() => setActiveNav(label)}><Icon size={17} strokeWidth={1.8} /><span>{label}</span>{badge && <span className="nav-badge">{badge}</span>}</button>)}</nav>
        <div className="nav-section-label care-label">CARE &amp; COMMUNITY</div>
        <nav className="main-nav"><button className="nav-item" onClick={() => announce('Appointments are up to date')}><CalendarDays size={17} strokeWidth={1.8} /><span>Appointments</span></button><button className="nav-item" onClick={() => announce('Opening teleconsultation queue')}><Stethoscope size={17} strokeWidth={1.8} /><span>Teleconsultations</span><span className="live-indicator" /></button><button className="nav-item" onClick={() => announce('Village health map selected')}><MapPin size={17} strokeWidth={1.8} /><span>Village coverage</span></button></nav>
        <div className="sidebar-spacer" />
        <div className="sync-card"><div className="sync-icon"><Cloud size={15} /></div><div className="sync-text"><strong>All caught up</strong><span>Last synced just now</span></div><Check size={14} className="sync-check" /></div>
        <div className="profile-card"><div className="profile-avatar">AM</div><div className="profile-copy"><strong>Ananya M.</strong><span>Health worker</span></div><MoreHorizontal size={19} className="muted" /></div>
      </aside>

      {mobileMenu && <button aria-label="Close navigation" className="mobile-backdrop" onClick={() => setMobileMenu(false)} />}

      <section className="main-panel">
        <header className="topbar"><div className="topbar-left"><button className="icon-button mobile-menu-button" aria-label="Open navigation" onClick={() => setMobileMenu(true)}><Menu size={19} /></button><div className="breadcrumb">East Godavari <ChevronRight size={14} /><strong>Overview</strong></div></div><div className="topbar-actions"><button className={`connection ${isOnline ? '' : 'offline'}`} onClick={() => setIsOnline(!isOnline)}>{isOnline ? <Cloud size={15} /> : <CloudOff size={15} />}<span>{isOnline ? 'Online' : 'Offline'}</span><i /></button><div className="topbar-divider" /><button className="icon-button help-button" aria-label="Help" onClick={() => announce('Help centre · Call 1800-XXX-XXXX')}><CircleHelp size={18} /></button><div className="notification-wrap"><button className="icon-button notification-button" aria-label="Notifications" onClick={() => setShowNotifications(!showNotifications)}><Bell size={18} /><i /></button>{showNotifications && <div className="notification-popover"><div className="popover-title">Notifications<span>2 new</span></div><div className="notification-item"><span className="notification-dot red" /><div><strong>High risk case needs review</strong><small>Ravi Mallesh · 12 min ago</small></div></div><div className="notification-item"><span className="notification-dot blue" /><div><strong>New referral appointment confirmed</strong><small>Tomorrow, 10:30 AM · Rajahmundry</small></div></div><button className="popover-footer" onClick={() => setShowNotifications(false)}>View all notifications</button></div>}</div><div className="topbar-divider" /><div className="topbar-date">Wednesday, 24 September</div><div className="topbar-avatar">AM</div></div></header>

        <div className="content-area">
          <div className="welcome-row"><div><div className="eyebrow"><span className="eyebrow-dot" />DISTRICT HEALTH OVERVIEW <span className="eyebrow-separator">/</span> WEEK 39</div><h1>Good morning, Ananya <span className="wave">✳</span></h1><p className="welcome-subtitle">Here&apos;s what&apos;s happening across your community today.</p></div><button className="primary-button" onClick={() => setShowRegistration(true)}><Plus size={17} strokeWidth={2.4} /> Register patient</button></div>

          <div className="notice-bar"><div className="notice-icon"><ShieldCheck size={17} /></div><span><strong>Community screening day</strong> is this Friday in Maredumilli block.</span><button onClick={() => announce('Campaign details opened')}>View campaign <ArrowRight size={14} /></button><button aria-label="Dismiss" className="notice-dismiss" onClick={e => e.currentTarget.parentElement?.remove()}><X size={15} /></button></div>

          <div className="section-heading"><div><h2>At a glance</h2><span>Updated just now <i className="fresh-dot" /></span></div><button className="date-filter" onClick={() => setActivePeriod(activePeriod === '7 days' ? '30 days' : '7 days')}><CalendarDays size={15} />{activePeriod}<ChevronDown size={14} /></button></div>

          <div className="stats-grid">
            <motion.article className="stat-card" initial={{ opacity: 0, y: 10 }} animate={{ opacity: 1, y: 0 }} transition={{ duration: 0.35 }}><div className="stat-top"><span className="stat-label">Total screenings</span><span className="stat-icon mint"><Activity size={17} /></span></div><div className="stat-value">1,284</div><div className="stat-bottom"><span className="trend positive"><ArrowUpRight size={14} />18.6%</span><span>vs. last {activePeriod}</span><div className="sparkline"><svg viewBox="0 0 90 28" preserveAspectRatio="none"><path d="M1 23 C12 18, 14 21, 22 15 S35 20, 44 13 S58 18, 66 9 S79 13, 89 3" /></svg></div></div></motion.article>
            <motion.article className="stat-card" initial={{ opacity: 0, y: 10 }} animate={{ opacity: 1, y: 0 }} transition={{ duration: 0.4, delay: 0.05 }}><div className="stat-top"><span className="stat-label">High-risk cases</span><span className="stat-icon coral"><Activity size={17} /></span></div><div className="stat-value">38</div><div className="stat-bottom"><span className="trend caution"><ArrowUpRight size={14} />5 new</span><span>need attention</span><span className="stat-foot-link" onClick={() => setActiveNav('Screenings')}>Review <ArrowRight size={13} /></span></div></motion.article>
            <motion.article className="stat-card" initial={{ opacity: 0, y: 10 }} animate={{ opacity: 1, y: 0 }} transition={{ duration: 0.45, delay: 0.1 }}><div className="stat-top"><span className="stat-label">Referrals completed</span><span className="stat-icon lavender"><Check size={17} /></span></div><div className="stat-value">74<span className="stat-unit">%</span></div><div className="stat-bottom"><span className="trend positive"><ArrowUpRight size={14} />12.3%</span><span>vs. last {activePeriod}</span><div className="mini-progress"><i /></div></div></motion.article>
            <motion.article className="stat-card response-card" initial={{ opacity: 0, y: 10 }} animate={{ opacity: 1, y: 0 }} transition={{ duration: 0.5, delay: 0.15 }}><div className="stat-top"><span className="stat-label">Avg. doctor response</span><span className="stat-icon peach"><Clock3 size={17} /></span></div><div className="stat-value">2.4<span className="stat-unit"> hrs</span></div><div className="stat-bottom"><span className="trend positive"><ArrowDownRight size={14} />32 min</span><span>faster this week</span><div className="avatar-stack"><span>SR</span><span>PK</span><span>+4</span></div></div></motion.article>
          </div>

          <div className="middle-grid">
            <section className="panel screenings-panel"><div className="panel-heading"><div><h3>Screening activity</h3><p>Patients screened over time</p></div><button className="quiet-button" onClick={() => announce('Screening report downloaded')}><Download size={14} /> Export</button></div><div className="chart-legend"><span><i />Screenings</span><span className="chart-annotation">Weekly goal <strong>350</strong></span></div><div className="chart-wrap"><ResponsiveContainer width="100%" height="100%"><AreaChart data={weekly} margin={{ top: 8, right: 7, left: -22, bottom: 0 }}><defs><linearGradient id="screeningFill" x1="0" y1="0" x2="0" y2="1"><stop offset="0%" stopColor="#087d67" stopOpacity={0.15} /><stop offset="95%" stopColor="#087d67" stopOpacity={0} /></linearGradient></defs><CartesianGrid vertical={false} stroke="#edf0ee" strokeDasharray="3 5" /><XAxis dataKey="day" tickLine={false} axisLine={false} tick={{ fontSize: 11, fill: '#a0a8a3' }} dy={10} /><YAxis tickLine={false} axisLine={false} tick={{ fontSize: 11, fill: '#a0a8a3' }} ticks={[0, 20, 40, 60, 80]} /><Tooltip contentStyle={{ border: '1px solid #e8ece9', borderRadius: 10, boxShadow: '0 8px 20px #18362912', fontSize: 12 }} cursor={{ stroke: '#c7dad3', strokeDasharray: '3 3' }} /><Area type="monotone" dataKey="count" stroke="#087d67" strokeWidth={2.4} fill="url(#screeningFill)" activeDot={{ r: 5, fill: '#087d67', stroke: '#fff', strokeWidth: 3 }} /></AreaChart></ResponsiveContainer></div><div className="chart-footer"><span><strong>327</strong> screenings this week</span><span className="goal-chip"><Check size={12} />93% of weekly goal</span></div></section>

            <section className="panel villages-panel"><div className="panel-heading"><div><h3>Village coverage</h3><p>Screenings across your block</p></div><button className="icon-button panel-more" aria-label="More village options" onClick={() => announce('Village coverage options')}><MoreHorizontal size={19} /></button></div><div className="village-list">{villages.map((v, i) => <div className="village-row" key={v.name}><div className="village-info"><div className="village-name">{v.name}</div><div className="village-count">{v.count} screened <span>·</span> <span className="village-high">{v.high} high risk</span></div></div><div className="village-bar"><i style={{ width: v.width }} className={i === 0 ? 'bar-strong' : ''} /></div><span className="village-rank">0{i + 1}</span></div>)}</div><button className="panel-footer-link" onClick={() => setActiveNav('Village coverage')}>Explore village map <ArrowRight size={14} /></button></section>
          </div>

          <section className="panel cases-panel"><div className="cases-heading"><div><div className="cases-title-line"><h3>Cases needing attention</h3><span className="case-count">8</span></div><p>Follow up on recent screenings and referrals.</p></div><button className="view-all" onClick={() => setActiveNav('Screenings')}>View all cases <ArrowRight size={14} /></button></div><div className="table-toolbar"><div className="search-box"><Search size={15} /><input placeholder="Search patients or ID..." value={query} onChange={e => setQuery(e.target.value)} /></div><button className="filter-button" onClick={() => announce('Showing high priority and recent cases')}><Filter size={14} /><span>Filter</span><span className="filter-count">2</span></button><div className="toolbar-spacer" /><span className="results-count">Showing <strong>{visibleCases.length}</strong> of 8 cases</span></div><div className="table-scroll"><table><thead><tr><th>PATIENT</th><th>AI FINDING</th><th>RISK SCORE</th><th>STATUS</th><th>LAST UPDATED</th><th /></tr></thead><tbody>{visibleCases.map((c, i) => <tr key={c.id} onClick={() => setSelectedCase(selectedCase === c.id ? null : c.id)} className={selectedCase === c.id ? 'row-selected' : ''}><td><div className="patient-cell"><div className={`patient-avatar avatar-${i}`}>{c.initials}</div><div><strong>{c.name}</strong><small>{c.id} <span>·</span> {c.village}</small></div></div></td><td><span className="finding-text">{c.finding}</span></td><td><RiskPill risk={c.risk} tone={c.tone} /></td><td><span className={`status-label ${c.tone}`}>{c.tone !== 'low' && <i />}{c.status}</span></td><td className="time-cell">{c.time}</td><td><button className="row-action" aria-label={`View ${c.name}`} onClick={e => { e.stopPropagation(); setSelectedCase(c.id); }}><ArrowRight size={15} /></button></td></tr>)}</tbody></table>{visibleCases.length === 0 && <div className="empty-state">No patients match “{query}”.</div>}</div><div className="table-bottom"><span><span className="tiny-shield"><ShieldCheck size={12} /></span> Patient data is encrypted and access is logged</span><button onClick={() => announce('Opening full case queue')}>Open case queue <ArrowRight size={13} /></button></div></section>

          <footer className="page-footer"><span>© 2025 Aarogya Drishti AI <span>·</span> Built for healthier communities</span><div><button onClick={() => announce('Support: help@aarogyadrishti.org')}>Support</button><button onClick={() => announce('Privacy policy opened')}>Privacy</button><button onClick={() => announce('Platform status: all systems operational')}>System status <i /></button></div></footer>
        </div>
      </section>

      {showRegistration && <div className="modal-backdrop" onClick={() => setShowRegistration(false)}><motion.div className="registration-modal" initial={{ opacity: 0, y: 12, scale: .98 }} animate={{ opacity: 1, y: 0, scale: 1 }} onClick={e => e.stopPropagation()}><div className="modal-heading"><div><div className="modal-kicker">NEW SCREENING</div><h2>Register a patient</h2><p>Start with the patient&apos;s basic details. You can complete the health history later.</p></div><button className="icon-button" aria-label="Close" onClick={() => setShowRegistration(false)}><X size={18} /></button></div><form onSubmit={e => { e.preventDefault(); setShowRegistration(false); announce('Patient registered · Offline ready'); }}><div className="form-grid"><label>Full name<input required placeholder="Patient's full name" /></label><label>Age<input required type="number" min="1" max="120" placeholder="Age in years" /></label><label>Mobile number<input type="tel" placeholder="+91 00000 00000" /></label><label>Village<input required placeholder="Search village" /></label><label className="full-field">Primary concern<select defaultValue=""><option value="" disabled>Select if reported</option><option>Mouth ulcer or sore</option><option>White or red patch</option><option>Difficulty opening mouth</option><option>No symptoms reported</option></select></label></div><div className="consent-note"><ShieldCheck size={15} /><span>Ask the patient for consent before collecting health details or taking photographs.</span></div><div className="modal-actions"><button type="button" className="secondary-button" onClick={() => setShowRegistration(false)}>Cancel</button><button type="submit" className="primary-button"><Plus size={16} /> Create patient record</button></div></form></motion.div></div>}

      {selectedCase && <div className="case-drawer-backdrop" onClick={() => setSelectedCase(null)}><motion.aside className="case-drawer" initial={{ x: 340 }} animate={{ x: 0 }} onClick={e => e.stopPropagation()}><div className="drawer-top"><span>CASE OVERVIEW</span><button className="icon-button" aria-label="Close case details" onClick={() => setSelectedCase(null)}><X size={18} /></button></div><div className="drawer-patient"><div className="patient-avatar drawer-avatar">{cases.find(c => c.id === selectedCase)?.initials}</div><h2>{cases.find(c => c.id === selectedCase)?.name}</h2><p>{selectedCase} · {cases.find(c => c.id === selectedCase)?.village}</p><RiskPill risk={cases.find(c => c.id === selectedCase)?.risk || 0} tone={cases.find(c => c.id === selectedCase)?.tone || 'low'} /></div><div className="drawer-section"><div className="drawer-section-label">SCREENING FINDING</div><h3>{cases.find(c => c.id === selectedCase)?.finding}</h3><p>AI assisted screening result. A qualified clinician should review the image and clinical context before diagnosis.</p></div><div className="drawer-section"><div className="drawer-section-label">CARE JOURNEY</div><div className="journey-step done"><i /><div><strong>Screening completed</strong><span>Today · 9:42 AM</span></div></div><div className="journey-step current"><i /><div><strong>Doctor review</strong><span>Awaiting clinician assessment</span></div></div><div className="journey-step"><i /><div><strong>Referral &amp; follow-up</strong><span>Next step</span></div></div></div><button className="primary-button drawer-button" onClick={() => { setSelectedCase(null); announce('Case opened for clinical review'); }}><FileText size={16} /> Open full case</button><button className="secondary-button drawer-message" onClick={() => announce('Message sent to care team')}><MessageCircle size={15} /> Contact care team</button></motion.aside></div>}

      <div className="assistant-fab" title="Aarogya voice assistant"><AudioLines size={17} /><span>Ask Aarogya</span><span className="fab-shortcut"><Headphones size={13} /></span></div>
      {toast && <div className="toast"><Check size={15} />{toast}</div>}
    </main>
  );
}
