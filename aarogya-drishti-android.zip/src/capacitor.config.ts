import type { CapacitorConfig } from '@capacitor/cli';

const config: CapacitorConfig = {
  appId: 'org.aarogyadrishti.app',
  appName: 'Aarogya Drishti AI',
  webDir: 'out', // Next.js static export folder
  android: { allowMixedContent: false },
  plugins: {
    SplashScreen: { launchShowDuration: 1200, backgroundColor: '#087d67', showSpinner: false },
    StatusBar: { style: 'DARK', backgroundColor: '#087d67' },
  },
};
export default config;
