# Aarogya Drishti AI – Android app: build & deploy

1. Create a free GitHub account → New repository `aarogya-drishti-ai` (private is fine).
2. Upload ALL files of this folder (drag & drop on the repo page, or `git push`). Keep the `.github` folder.
3. Open the repo → Actions tab → "Build Android APK" → Run workflow. Wait ~6–10 min.
4. Open the finished run → Artifacts → download `aarogya-drishti-debug-apk` → unzip → `app-debug.apk`.
5. Send the APK to your phone, tap it, allow "Install unknown apps", install.
6. Backend: render.com → New → Blueprint → select the repo (uses render.yaml). Test `<url>/health`.
7. Release: `git tag v1.0.0 && git push --tags` – the APK is attached to a GitHub Release automatically.
8. Play Store later: needs a signed release build (.aab) + a Google Play developer account (one-time US$25).

Run locally: `npm install && npm run build && npx cap add android && npx cap sync android && npx cap open android` (needs Android Studio).
